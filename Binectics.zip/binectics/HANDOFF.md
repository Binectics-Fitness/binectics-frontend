# Binectics — Design Handoff

This document is for any designer or agent picking up the project. Read it before adding new surfaces. The prototype is in `binectics/` — open `index.html` to navigate everything that's built.

---

## 1. Direction in one sentence

**"Operating system for fitness."** Position closer to Stripe Dashboard and Linear than to ClassPass, MyFitnessPal, or any wellness lifestyle app. Confident, utilitarian, restrained. The fitness energy comes through in **photography and a single celebratory moment**, never in the chrome.

If a design decision would feel at home on a Headspace marketing page, it's probably wrong for Binectics.

## 2. Why this direction

Binectics is a two‑sided marketplace + operational tool spanning **5 roles** (consumer, gym, trainer, dietitian, admin), **50+ countries**, **8 currencies**. The product has to feel:
- Serious enough for a gym owner reviewing revenue at 11pm
- Welcoming enough for someone booking their first yoga class
- Dense enough for admins moderating listings
- The same in São Paulo, Lagos, Berlin, and Jakarta

A wellness‑pastel UI loses the gym owner. A gym‑bro UI loses the yoga beginner. Stripe‑adjacent restraint serves everyone because it gets out of the way and lets the actual content (people, places, prices, outcomes) carry the meaning.

## 3. The color system

Defined in `shared.css` under `:root`. **Do not invent new colors.** If you need a new one, derive it in oklch with matched lightness/chroma to an existing one.

### Neutrals (carry 95% of the UI)
- `--bg` `oklch(0.985 0.005 85)` — warm off‑white, primary background
- `--bg-2` / `--bg-3` — slightly darker neutrals for sections, cards, hover
- `--ink` `oklch(0.16 0.01 80)` — near‑black with warm cast, primary text
- `--fg-2 / --fg-3 / --fg-4` — text hierarchy
- `--border / --border-2` — 1px hairlines, no shadows

### One signal color
- `--signal` `oklch(0.72 0.18 145)` — athletic, slightly desaturated green
- Used **only** for: primary CTAs, "verified" badges, success states, the check‑in success moment
- **Resist coloring anything else with it.** That's the whole point.

### Role accents (matched at lightness ~0.55, chroma ~0.15)
- `--consumer` violet · `--gym` blue · `--trainer` amber · `--dietitian` deeper violet
- Used as: small dots, left borders on cards, role pills, dashboard accents
- Matched lightness means a screen showing all four roles harmonizes — no clown‑car effect

### Semantic only for semantic
- `--danger` red · `--warn` amber
- Never decorative. A red dot means something is wrong.

## 4. Typography

System defined in `shared.css`:
- **Display + body:** Inter (placeholder for Söhne/GT America if licensed). Tight tracking at large sizes (`letter-spacing: -0.025em` at 36px+, `-0.02em` at 24px+).
- **Mono:** JetBrains Mono for: numerals in dashboards, labels, timestamps, IDs, currency, all caps micro‑labels at 10–11px.
- **Tabular figures everywhere on numbers** — `font-variant-numeric: tabular-nums` on any column that contains money, counts, percentages.
- One serif moment allowed: editorial hero quotes on marketing pages only. Not in product chrome.

## 5. Layout rules

- **Hard‑edged or barely‑rounded.** `--r-1: 4px` · `--r-2: 6px` · `--r-3: 8px`. Never go bigger.
- **1px hairlines, no floating shadows.** Use `--border` to define edges. Shadows are reserved for: focused inputs (none currently), modals, the check‑in success card.
- **Generous whitespace.** Dashboards breathe at the top, pack density underneath. Marketplace and provider pages get editorial‑magazine air.
- **Grid + flex with `gap:`, never bare inline siblings.** Already a project rule.

## 6. Iconography

- **Lucide only**, 1.5px stroke, never filled.
- Don't mix filled and outlined.
- Don't use emoji. Brand is not emoji‑coded.
- If an icon would feel decorative rather than informational, leave it out.

## 7. Motion

Tokens in `shared.css`:
- `--motion-fast: 120ms` — hover color/border transitions
- `--motion-base: 220ms` — UI state changes
- `--motion-slow: 360ms` — sheet opens, modals
- `--motion-hero: 600ms` — reserved for the check‑in success only

**The only animated celebratory moment in the system is the QR check‑in success** (`checkin.html`). Everywhere else: 120ms color changes, that's it. No button pulses. No skeleton shimmers that draw attention. No confetti. No micro‑interactions that brag.

## 8. Photography

Warmth lives here, exclusively. Use:
- **4:5 portrait crops** for trainers and dietitians
- **16:9 environmental shots** for gyms and studios
- **1:1 overhead** for dietitian meal photography
- Real provider photos at large scale, framed as quiet placeholders (`bg-2` or `bg-3` fill with a small label) when not yet supplied — do not draw fake photo content in SVG.

## 9. File structure

```
binectics/
├── index.html              hub — links to every surface
├── HANDOFF.md              this file
├── shared.css              all design tokens + base components
├── brand.html              logo, wordmark, construction, voice
├── design-system.html      colors, type, components, patterns
├── landing.html            public marketing
├── marketplace.html        browse providers
├── provider.html           single provider detail
├── dashboard-gym.html      gym owner operational view
├── dashboard-trainer.html  trainer operational view
├── dashboard-dietitian.html dietitian operational view
├── admin.html              super admin console
├── onboarding.html         5-step multi-role onboarding
└── checkin.html            QR check-in success moment
```

Every page imports `shared.css` and uses only tokens defined there. No page-specific color values, no inline hex codes for anything semantic.

## 10. The logo

Defined inline as SVG on `brand.html` and reused in every header. Two nested arcs (open C-curves), 6px stroke, round caps. The opening on the right reads as a *connection point* — between members and providers, between body and mind. Don't redraw it. Copy the SVG.

```html
<svg viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="6" stroke-linecap="round">
  <path d="M 32 6 A 18 18 0 1 0 32 42"/>
  <path d="M 28 16 A 8 8 0 1 0 28 32"/>
</svg>
```

Wordmark is the type family at medium weight, slightly tightened. The mark works alone (favicon, app icon, kiosk corner). The lockup is mark + wordmark with ~6px gap.

## 11. What's built vs. what's not

### Built (21 surfaces)
Foundation: `brand`, `design-system`
Public: `landing`, `marketplace`, `provider`
Dashboards: `dashboard-gym`, `dashboard-trainer`, `dashboard-dietitian`, `admin`
Flows: `onboarding`, `checkin`
**Phase 1 — Booking spine:** `auth`, `booking`, `booking-confirmed`, `my-bookings`
**Phase 2 — Provider loop:** `client`, `messages`, `calendar`
**Phase 3 — Deep work:** `plan-builder`, `profile-edit`
Plus: `index` hub

### Patterns established in Phase 3 (reuse, don't reinvent)
- **Four‑column app layout** — `plan-builder.html` and `messages.html`. Sidebar / library or inbox / main canvas / inspector. Use for any "build a thing" surface.
- **Drag‑from‑library tiles** — `plan-builder.html`. Grip handle, icon, name, meta line, `.pulled` state when in use. Reuse for any drag‑drop builder (meal plan, content scheduler).
- **Inspector with AI suggestions** — `plan-builder.html`. AI rows with primary/secondary action buttons that mutate the canvas.
- **Long‑form edit page with sticky section nav + live preview** — `profile-edit.html`. Section nav with completion checkmarks, scrolling sections, sticky preview rail. Use for settings, gym listing edit, dietitian profile edit, member account.
- **Verification doc rows** — `profile-edit.html`. Color-coded by status (verified / expiring / missing). `.expiring` amber drives action.
- **Search-rank tip card** — `profile-edit.html`. Current rank + one concrete improvement. Specific beats generic encouragement.

### Patterns established in Phase 2 (reuse, don't reinvent)
- **Tabbed detail page with sticky tab bar** — `client.html`. Hero block on top, sticky tab nav below at `top: 56px`, body with main + right rail. Use for any drill-in (single booking, single session, single provider edit).
- **Three‑pane inbox layout** — `messages.html`. Sidebar / inbox list / thread / context rail. The context rail is what makes the messages screen useful — reuse it for any conversation surface.
- **Coaching notes with type pills** — `client.html`. Compose-at-bottom, list-above pattern. Type pills (`After session / Programming / Health flag / Personal`) before save. Worth copying for any timeline-of-records UI.
- **Week-grid calendar with availability shading** — `calendar.html`. Repeating diagonal stripes for available time, solid event blocks on top. Working-hours editor on the right rail.
- **Status badge with semantic dot** — used across all of Phase 2. `.pill-i.signal/danger/warn` with a colored `.dot` inside. Same component, three palettes.
- **Signals card** — `client.html` right rail. AI-detected nudges with a colored vertical bar on the left (good/warn/info). Reuse anywhere we want to surface insights without a separate "AI" tab.
- **3-step wizard with sticky footer** — `booking.html`. Stepper at top, panels swap via JS, right rail summary always visible, sticky footer with back / continue.
- **Right-rail summary while a user fills a form** — `booking.html`, `onboarding.html`. Always show the user what they're committing to.
- **Status pills with dot** — `my-bookings.html`. `.status.confirmed/pending/done/cancelled`. Use these everywhere a row needs a state.
- **Receipt table** — `booking-confirmed.html`, `my-bookings.html`. Mono numerals, hairline rows, total at the bottom with sans-serif larger size.
- **Editorial right panel for auth** — `auth.html`. Dark ink panel with serif italic quote + 3-stat strip. Reuse for any account-creation surface.
- **QR code rendering** — `booking-confirmed.html` + `my-bookings.html` + `checkin.html`. Deterministic JS pattern generator. Copy the snippet.

### Not yet built (priority order)
1. **Modal + drawer + toast system** — system primitives. Once built, every surface gets richer interactions for free.
2. **Member mobile app** — iOS + Android. Use `ios_frame.jsx` / `android_frame.jsx` starters.
3. **Settings / account screens** — per role. `profile-edit.html` pattern carries over directly.
4. **Email + push notification templates** — ~22 templates.
5. **Customer support console** — dispute resolution.
6. **Marketing system pages** — pricing, careers, T&S, status.

### Composition rules for new surfaces
- Read this file first. Then `design-system.html` in the browser. Then the closest analogous existing page.
- New colors → no.
- New border radii → no.
- New icon style → no.
- New typography weight or size beyond what's in `design-system.html` → ask the user first.
- New animation → only if it serves comprehension (loading a heavy table, scrubbing a chart). Never celebratory.

## 12. Voice & copy

- **Sentence case** for everything except acronyms. No Title Case Headlines.
- **Honest, specific, declarative.** "₦ 1.84M booked · next payout May 13" not "You're crushing it this month! 🚀"
- **Don't invent stats.** Mocked numbers should be plausible for the role and region — a Lagos trainer doesn't bill in dollars; a Berlin gym shows VAT.
- **No exclamation marks** in product copy. Marketing pages get one or two, max.
- **Localization‑aware.** Date formats, currency symbols, address patterns. If a string is country‑specific, mark it `data-locale="ng"` or similar.

## 13. The one rule above all others

**A thousand no's for every yes.** If a section feels empty, that's a layout problem, not a content problem. Don't fill space with stats nobody will read, icons nobody needs, or "value props" the user already understood. Restraint is the brand.

---

*Last updated by Claude on initial build. Update this file when you add new pages, new tokens, or new patterns.*

---

## 14. Complete page inventory — what's left

Collated from every link in the existing chrome (landing nav, landing footer, dashboard sidebars, marketplace nav, provider profile actions, my-bookings nav) plus implicit screens the system needs to actually run. **21 surfaces built · ~172 remaining · ~186 total.**

### A · Landing nav + hero CTAs (10)
A1 How it works · A2 For providers · A3 For gyms · A4 For trainers · A5 For dietitians · A6 For members · A7 Pricing · A8 FAQ · A9 Start your gym (provider signup intent) · A10 Create your account (consumer signup intent)

### B · Landing footer · Company (4)
B1 About · B2 Careers · B3 Press · B4 Partners

### C · Landing footer · Resources (7)
C1 Help center home · C2 Single article · C3 Category page · C4 QR / kiosk setup · C5 System status · C6 Changelog · C7 Brand assets download

### D · Landing footer · Legal (6)
D1 Privacy · D2 Terms · D3 Cookies · D4 Security · D5 Trust & safety · D6 Acceptable use

### E · Auth & lifecycle gaps (7)
E1 Reset password with token · E2 Email verify success/failure · E3 Magic link consume · E4 Account suspended · E5 Account deleted goodbye · E6 Session expired · E7 Role picker

### F · Consumer · member side (17)
F1 Search results · F2 Marketplace map view · F3 Saved/favorites · F4 Single booking detail · F5 Reschedule flow · F6 Cancel & refund flow · F7 Review provider · F8 Member public profile · F9 Health log · F10 Workout log · F11 Meal log · F12 Streaks/gamification · F13 Member messages · F14 Member settings · F15 Payment methods · F16 Billing history · F17 Help / support inbox

### G · Gym owner (20)
G1 Members list · G2 Single member · G3 Plans/memberships editor · G4 Class schedule editor · G5 Single class · G6 Check-in log / kiosk health · G7 Staff list · G8 Staff detail / scopes · G9 Assignment rules · G10 Org switcher modal · G11 Single location · G12 Add location wizard · G13 Revenue reports · G14 Payouts list · G15 Single payout · G16 Tax / SARS forms · G17 Gym listing edit · G18 Reviews moderation · G19 Marketing tools · G20 Gym settings

### H · Trainer (10)
H1 Clients list · H2 Sessions list · H3 Earnings detail · H4 Tax docs · H5 Payout setup · H6 Packages editor full · H7 Single client invite · H8 Bulk client invite · H9 Reviews moderation · H10 Trainer settings

### I · Dietitian (7)
I1 Meal plan builder · I2 Food database browser · I3 Single food · I4 Protocol library · I5 Dietitian client view · I6 PDF plan preview · I7 Meal feedback inbox

### J · Admin / platform-ops (15)
J1 Single listing review · J2 Listing reject flow · J3 User detail (admin) · J4 Impersonate user landing · J5 Single dispute detail · J6 Dispute resolution flow · J7 Single country dashboard · J8 Financial / GMV reports · J9 Single fraud signal · J10 Content moderation queue · J11 Single review admin · J12 Audit log detail · J13 Feature flag detail · J14 Admin team & roles · J15 Tax / compliance per country

### K · System primitives — cross-cutting (20)
K1 Modal · cancel confirmation · K2 Modal · refund flow · K3 Modal · report/flag · K4 Modal · image lightbox · K5 Modal · add payment method · K6 Modal · switch role · K7 Modal · delete account · K8 Modal · currency/language switcher · K9 Drawer · notifications · K10 Drawer · single client peek · K11 Drawer · activity log · K12 Drawer · cmd-K search · K13 Toast system · K14 Banner system · K15 Empty states (12 variants) · K16 Loading skeletons · K17 Error 404 · K18 Error 500 · K19 Maintenance · K20 Offline / PWA fallback

### L · Mobile · member + provider apps (24)
~12 screens × 2 platforms (iOS + Android), mostly shared React app:
Home/discover · Search · Provider profile · Booking flow · Booking confirmed · My bookings list + detail · QR check-in · Messages · Activity/streaks · Settings · Auth · Push permissions

### M · Email + push template kit (22)
Booking confirmed · reminder 24h · reminder 1h · cancelled · refunded · rescheduled · new message · plan delivered · weekly summary member · weekly summary provider · payout sent · payout failed · KYC approved · KYC rejected · listing approved · listing rejected · password reset · welcome × 4 roles · review request · review received · dispute opened · resolution

### Tally

| Bucket | Built | Remaining |
|---|---|---|
| Marketing (A+B+C+D) | 0 | 30 |
| Auth & lifecycle (E) | 1 | 7 |
| Consumer (F) | 4 | 17 |
| Gym (G) | 1 | 20 |
| Trainer (H) | 6 | 10 |
| Dietitian (I) | 1 | 7 |
| Admin (J) | 1 | 15 |
| System primitives (K) | 0 | 20 |
| Mobile (L) | 0 | 24 |
| Email + push (M) | 0 | 22 |
| **Total** | **14** | **172** |

The other 7 of the 21 built (`brand`, `design-system`, `index`, `checkin`, `onboarding`, `dashboard-trainer`, `dashboard-dietitian`) are reference / chrome surfaces not counted in their respective rows.

### What to build next, in priority order

1. **Footer legal trio** (D1–D3) — required to launch, easy to template once
2. **Modal + drawer + toast system** (K1–K13) — unlocks polish across all 21 existing pages
3. **Pricing page** (A7) — needed before any provider acquisition campaign
4. **Reschedule + cancel + refund flows** (F5–F6, K1, K2) — these get used hourly in production
5. **Member settings + payment methods** (F14–F16) — every consumer needs them
6. **Member mobile app** (L) — the single biggest gap by audience size

