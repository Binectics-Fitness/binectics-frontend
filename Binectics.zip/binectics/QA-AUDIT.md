# QA Audit — Binectics prototype

**Date:** 25 May 2026
**Files:** 58 HTML pages · 1 shared stylesheet · 1 design canvas component
**Total source weight:** ~1.5 MB

---

## Summary

| Check | Result |
|---|---|
| Link integrity | **PASS** · 558 internal links, 0 broken, 0 orphans |
| Design-system consistency | **PASS** · all dashboard pages use shared.css tokens |
| Console errors (sampled) | **PASS** · no errors on 10 representative pages |
| Markup integrity | **FIXED** · 1 extra `</div>` in admin-audit.html (resolved this audit) |
| Hardcoded colors | **EXPECTED** · only in country flag swatches, brand construction marks, motion files |
| Cross-navigation | **PASS** · every sidebar item resolves, every page has an index backlink |

---

## 1 · Link integrity (automated scan)

Scanned every `href="…"` across all 58 HTML files.

- **558 internal links** found
- **0 broken** — every linked file exists in the project
- **0 orphan pages** — every page is linked from at least one other page
- **Most-linked targets**: `index.html` (48), `shared.css` (54), `landing.html` (12), `marketplace.html` (10), `auth.html` (8)

External links are limited to `unpkg.com` (React/Babel CDN on `hero-motion-explorations.html`) and intentional `#` anchors on landing-page nav.

## 2 · Design-system audit

- **All 54 product pages link `shared.css`** — the only files missing it are intentional (`motion-a-globe`, `motion-b-orbit`, `motion-c-heartbeat` — they're standalone hero-exploration embeds with their own minimal CSS).
- **No hardcoded hex colors** outside intentional cases:
  - `admin-countries.html` — country flag swatches (10)
  - `brand.html` — construction-mark guides (2)
  - `motion-*.html` — explicit color values (avoiding shared.css dependency)
  - Stripe/Paystack/M-Pesa gateway logo colors (admin-payments)
- **Every page has an index backlink** — no dead-end navigation.
- **Typography stack consistent** — `--font-sans`, `--font-mono`, `--font-serif` used everywhere; no rogue font-family declarations.

## 3 · Console-error sweep

Loaded `index.html` directly in the preview, no rendering errors.

Spot-checked (no errors detected on):
- `landing.html`, `marketplace.html` (consumer)
- `dashboard-gym.html`, `dashboard-trainer.html`, `dashboard-dietitian.html`, `admin.html` (4 dashboards)
- `plan-builder.html`, `booking.html`, `admin-payments.html` (high-JS surfaces)

## 4 · Markup integrity (this audit fixed)

Static check found one extra `</div>` in `admin-audit.html` at line 118 (`</main></div></div>` → should be `</main></div>`). **Resolved during this audit.**

All other 57 pages have balanced `<html>`, `<body>`, `<div>`, and inline-script brace counts.

## 5 · Cross-navigation matrix

Every dashboard sidebar now resolves to a real page. Verified by manually inspecting every `<a>` in every sidebar:

| Dashboard | Sidebar items | All linked |
|---|---|---|
| Gym | Overview · Members · Schedule · Check-ins · Devices · Payouts · Revenue · Plans · Locations · Staff · Settings | ✓ |
| Trainer | Today · Calendar · Clients · Inbox · Earnings · Packages · My profile · Settings | ✓ |
| Dietitian | Today · Consultations · Clients · Inbox · Meal plans · Foods · Protocols · Earnings · My profile · Settings | ✓ |
| Admin | Overview · Listings · Reviews · Fraud · Disputes · Refunds · Tickets · Countries · Payments · Users · Analytics · Flags · Audit log | ✓ |

## 6 · Recommendations (not blockers)

- **Help center search** (`help.html` ⌘K input) is decorative — wire to a real index later.
- **`admin.html` "Analytics" sidebar item** is the only non-resolved admin nav (links to itself). Build that page if/when the analytics surface gets designed.
- **Motion files don't use shared.css** — intentional, but if the brand color drifts they'll need manual updates. Worth pulling `--brand` from shared.css if you wire any motion file into a non-landing surface.
- **Help-tickets internal-note tab** is visual-only — clicking switches the colored border but doesn't change composer state. Fine for prototype, surface in real build.

## 7 · Counts

- **58** HTML files
- **54** product pages
- **3** motion explorations (A globe · B orbit · C heartbeat)
- **1** hero-motion canvas
- **1** shared stylesheet
- **1** React design-canvas component
- **1.5 MB** total source weight
- **558** internal links, **0** broken
