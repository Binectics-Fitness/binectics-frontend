/* Binectics — shared modal system
   ─────────────────────────────────
   Drop this on any page:
     <script src="modals.js"></script>
   Then wire any button:
     <button data-modal="new-plan">+ New plan</button>
     <button data-modal="confirm" data-confirm-title="Suspend user?"
             data-confirm-body="This freezes their account..."
             data-confirm-action="Suspend" data-confirm-tone="danger">Suspend</button>
   Programmatic:  Modals.open('new-plan');  Modals.close();  Modals.toast('Saved.');
*/
(function () {
  'use strict';

  // ---------- STYLES ---------- (injected once, scoped to bx- prefix)
  const css = `
  .bx-scrim { position: fixed; inset: 0; background: oklch(0 0 0 / 0.45); display: none; align-items: center; justify-content: center; z-index: 9999; padding: 24px; backdrop-filter: blur(2px); }
  .bx-scrim.on { display: flex; }
  .bx-modal { background: var(--bg, #fff); border-radius: 16px; width: 100%; max-width: 480px; max-height: 92vh; overflow: hidden; display: flex; flex-direction: column; box-shadow: 0 20px 60px oklch(0 0 0 / 0.20); font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif; color: var(--ink, #1a1814); }
  .bx-modal.wide { max-width: 580px; }
  .bx-modal-head { padding: 20px 24px 14px; border-bottom: 1px solid var(--border, #ebe7e1); display: flex; justify-content: space-between; align-items: flex-start; gap: 14px; flex-shrink: 0; }
  .bx-modal-head h3 { font-size: 18px; font-weight: 500; letter-spacing: -0.012em; line-height: 1.3; margin: 0; color: var(--ink, #1a1814); }
  .bx-modal-head .sub { font-size: 13px; color: var(--fg-3, #75716b); margin-top: 5px; line-height: 1.5; }
  .bx-x { color: var(--fg-3, #75716b); cursor: pointer; width: 24px; height: 24px; border-radius: 4px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
  .bx-x:hover { background: var(--bg-2, #f4f0e9); color: var(--ink); }
  .bx-x svg { width: 14px; height: 14px; stroke: currentColor; fill: none; stroke-width: 1.7; }
  .bx-modal-body { padding: 18px 24px; font-size: 14px; line-height: 1.55; color: var(--fg-2, #4a4640); overflow-y: auto; }
  .bx-modal-body strong { color: var(--ink); font-weight: 500; }
  .bx-modal-body p { margin: 0 0 12px; } .bx-modal-body p:last-child { margin-bottom: 0; }
  .bx-modal-foot { padding: 14px 24px; background: var(--bg-2, #f4f0e9); border-top: 1px solid var(--border, #ebe7e1); display: flex; justify-content: flex-end; gap: 8px; flex-shrink: 0; align-items: center; }
  .bx-modal-foot.spread { justify-content: space-between; }
  .bx-modal-foot .left { font-family: ui-monospace, monospace; font-size: 10.5px; color: var(--fg-3, #75716b); text-transform: uppercase; letter-spacing: 0.04em; }

  .bx-btn { font: inherit; font-size: 13.5px; padding: 9px 16px; border-radius: 8px; cursor: pointer; border: 1px solid transparent; font-weight: 500; transition: background 0.12s, border-color 0.12s; }
  .bx-btn.primary { background: var(--ink, #1a1814); color: var(--bg, #fff); }
  .bx-btn.primary:hover { background: #000; }
  .bx-btn.ghost { background: transparent; border-color: var(--border, #ebe7e1); color: var(--ink); }
  .bx-btn.ghost:hover { background: var(--bg-2, #f4f0e9); }
  .bx-btn.danger { background: var(--danger, #c0392b); color: #fff; }
  .bx-btn.danger:hover { background: #a8331f; }
  .bx-btn.signal { background: var(--signal, #6fbf63); color: oklch(0.18 0.05 148); }
  .bx-btn.signal:hover { filter: brightness(0.95); }

  .bx-field { display: flex; flex-direction: column; gap: 6px; margin-bottom: 14px; }
  .bx-field label { font-family: ui-monospace, monospace; font-size: 10.5px; text-transform: uppercase; letter-spacing: 0.06em; color: var(--fg-3, #75716b); }
  .bx-field input, .bx-field select, .bx-field textarea {
    background: var(--bg, #fff); border: 1px solid var(--border-2, #d8d3cc); border-radius: 8px;
    padding: 10px 12px; font: inherit; font-size: 14px; color: var(--ink); width: 100%;
    transition: border-color 0.12s;
  }
  .bx-field input:focus, .bx-field select:focus, .bx-field textarea:focus { outline: none; border-color: var(--ink); }
  .bx-field textarea { resize: vertical; min-height: 70px; line-height: 1.5; }
  .bx-field .hint { font-size: 12px; color: var(--fg-3, #75716b); }
  .bx-row-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin-bottom: 14px; }
  .bx-row-2 .bx-field { margin-bottom: 0; }

  .bx-picker { display: flex; flex-direction: column; gap: 6px; margin: 6px 0 12px; }
  .bx-opt { padding: 12px 14px; border: 1px solid var(--border, #ebe7e1); border-radius: 10px; cursor: pointer; display: flex; gap: 10px; align-items: center; transition: border-color 0.12s, background 0.12s; }
  .bx-opt:hover { border-color: var(--border-2, #d8d3cc); }
  .bx-opt.on { border-color: var(--ink); background: var(--bg-2, #f4f0e9); }
  .bx-opt .radio { width: 14px; height: 14px; border: 1px solid var(--border-2, #d8d3cc); border-radius: 50%; flex-shrink: 0; display: inline-flex; align-items: center; justify-content: center; margin-top: 2px; }
  .bx-opt.on .radio { border-color: var(--ink); }
  .bx-opt.on .radio::after { content: ""; width: 6px; height: 6px; background: var(--ink); border-radius: 50%; }
  .bx-opt .t { font-size: 13.5px; color: var(--ink); font-weight: 500; }
  .bx-opt .s { font-size: 12px; color: var(--fg-3, #75716b); margin-top: 2px; line-height: 1.45; }
  .bx-opt .icn { width: 32px; height: 32px; border-radius: 8px; background: var(--bg-2, #f4f0e9); flex-shrink: 0; display: flex; align-items: center; justify-content: center; }
  .bx-opt .icn svg { width: 16px; height: 16px; stroke: var(--ink); fill: none; stroke-width: 1.5; }

  .bx-tabs { display: inline-flex; padding: 3px; background: var(--bg-2, #f4f0e9); border-radius: 8px; gap: 2px; margin-bottom: 14px; }
  .bx-tab { padding: 6px 12px; font-size: 12.5px; color: var(--fg-3, #75716b); border-radius: 6px; cursor: pointer; background: transparent; border: 0; font-weight: 500; font-family: inherit; }
  .bx-tab.on { background: var(--bg, #fff); color: var(--ink); box-shadow: 0 1px 2px oklch(0 0 0 / 0.06); }

  .bx-callout { display: flex; gap: 10px; align-items: flex-start; padding: 11px 14px; background: var(--danger-soft, #f9e1de); border: 1px solid oklch(0.88 0.05 25); border-radius: 8px; margin-top: 12px; }
  .bx-callout .ico { width: 14px; height: 14px; color: var(--danger, #c0392b); flex-shrink: 0; margin-top: 2px; }
  .bx-callout svg { width: 100%; height: 100%; stroke: currentColor; fill: none; stroke-width: 1.7; }
  .bx-callout .t { font-size: 12.5px; color: var(--ink); line-height: 1.5; }
  .bx-callout.warn { background: oklch(0.96 0.06 75); border-color: oklch(0.88 0.07 75); }
  .bx-callout.warn .ico { color: oklch(0.45 0.16 75); }
  .bx-callout.info { background: var(--gym-soft, #e4ecf6); border-color: oklch(0.88 0.04 248); }
  .bx-callout.info .ico { color: var(--gym, #2a5b9e); }

  /* Toast */
  .bx-toast-stack { position: fixed; right: 24px; bottom: 24px; display: flex; flex-direction: column; gap: 8px; z-index: 10000; }
  .bx-toast { background: var(--ink, #1a1814); color: var(--bg, #fff); padding: 12px 16px; border-radius: 12px; min-width: 280px; max-width: 380px; box-shadow: 0 6px 20px oklch(0 0 0 / 0.12); display: flex; gap: 10px; align-items: center; font-size: 13px; transform: translateY(8px); opacity: 0; transition: transform 0.2s, opacity 0.2s; }
  .bx-toast.on { transform: translateY(0); opacity: 1; }
  .bx-toast.success { background: var(--signal, #6fbf63); color: oklch(0.18 0.05 148); }
  .bx-toast.danger  { background: var(--danger, #c0392b); color: #fff; }
  .bx-toast .ico { width: 16px; height: 16px; flex-shrink: 0; }
  .bx-toast .ico svg { width: 100%; height: 100%; stroke: currentColor; fill: none; stroke-width: 1.8; }
  .bx-toast .undo { font-family: ui-monospace, monospace; font-size: 10.5px; padding: 3px 8px; border-radius: 4px; border: 1px solid currentColor; opacity: 0.8; cursor: pointer; text-transform: uppercase; letter-spacing: 0.04em; }
  .bx-toast .undo:hover { opacity: 1; }
  `;

  const style = document.createElement('style');
  style.textContent = css;
  document.head.appendChild(style);

  // ---------- MODAL TEMPLATES ----------
  const TEMPLATES = {

    'new-flag': () => ({
      title: 'New feature flag',
      sub: 'Goes live in under 5 seconds. Every toggle is audit-logged.',
      body: `
        <div class="bx-field"><label>Flag key</label><input placeholder="checkin_v2_animation" /></div>
        <div class="bx-field"><label>Description</label><textarea placeholder="What does this flag do? Keep it short — future you will thank you."></textarea></div>
        <div class="bx-row-2">
          <div class="bx-field"><label>Owner</label><input placeholder="andile@binectics" /></div>
          <div class="bx-field"><label>Initial rollout</label><select><option>Off (0%)</option><option>1% canary</option><option>10%</option><option>25%</option><option>50%</option><option>100% on</option></select></div>
        </div>
        <div class="bx-field"><label>Targeting</label><select><option>All users</option><option>By country</option><option>By role</option><option>By cohort</option></select></div>
        <div class="bx-callout info"><span class="ico"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 16v-4M12 8h.01"/></svg></span><span class="t">Flag changes propagate to all clients within 5 seconds. Kill switch always available from this page.</span></div>`,
      foot: `
        <button class="bx-btn ghost" data-close>Cancel</button>
        <button class="bx-btn primary" data-action="create-flag">Create flag</button>`
    }),

    'new-plan': () => ({
      title: 'Create a new plan',
      sub: "Pick a template — you'll customize it next.",
      wide: false,
      body: `
        <div class="bx-picker" data-radio>
          <div class="bx-opt on" data-value="strength">
            <span class="icn"><svg viewBox="0 0 24 24"><path d="M6 4v16M18 4v16M3 8h3M3 16h3M18 8h3M18 16h3M6 12h12"/></svg></span>
            <span class="radio"></span>
            <div><div class="t">Strength &amp; conditioning</div><div class="s">12-week block · sets/reps/RPE · drag-drop builder</div></div>
          </div>
          <div class="bx-opt" data-value="meal">
            <span class="icn"><svg viewBox="0 0 24 24"><path d="M3 7h18M3 12h18M3 17h12M6 3v18"/></svg></span>
            <span class="radio"></span>
            <div><div class="t">Meal plan</div><div class="s">Macros · West African / standard food DB · PDF export</div></div>
          </div>
          <div class="bx-opt" data-value="membership">
            <span class="icn"><svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg></span>
            <span class="radio"></span>
            <div><div class="t">Gym membership tier</div><div class="s">Pricing · access · perks · auto-renew rules</div></div>
          </div>
          <div class="bx-opt" data-value="program">
            <span class="icn"><svg viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 3v18"/></svg></span>
            <span class="radio"></span>
            <div><div class="t">Custom program template</div><div class="s">Save once · reuse across clients</div></div>
          </div>
        </div>
        <div class="bx-field">
          <label>Plan name</label>
          <input placeholder="Untitled strength block" />
        </div>`,
      foot: `
        <button class="bx-btn ghost" data-close>Cancel</button>
        <button class="bx-btn primary" data-action="create">Continue → builder</button>`
    }),

    'book-session': () => ({
      title: 'Book a session',
      sub: 'Schedule with a client. Confirmation sends as soon as you save.',
      body: `
        <div class="bx-field">
          <label>Client</label>
          <input placeholder="Type a name…" value="Linda Mokoena" />
          <span class="hint">Recent · Linda M. · Wei C. · Aman R. · Pier B.</span>
        </div>
        <div class="bx-row-2">
          <div class="bx-field"><label>Date</label><input type="date" value="2026-05-28" /></div>
          <div class="bx-field"><label>Time</label><input type="time" value="08:30" /></div>
        </div>
        <div class="bx-row-2">
          <div class="bx-field">
            <label>Duration</label>
            <select><option>60 min</option><option>45 min</option><option>30 min</option><option>90 min</option></select>
          </div>
          <div class="bx-field">
            <label>Location</label>
            <select><option>Iron Lab Sea Point</option><option>Online · Zoom</option><option>Client's home</option></select>
          </div>
        </div>
        <div class="bx-field">
          <label>Note to client (optional)</label>
          <textarea placeholder="Bring water and your last week's log…"></textarea>
        </div>`,
      foot: `
        <button class="bx-btn ghost" data-close>Cancel</button>
        <button class="bx-btn primary" data-action="book">Book &amp; send confirmation</button>`
    }),

    'invite-client': () => ({
      title: 'Invite a new client',
      sub: 'Send a personal link or email. Most coaches use email — better conversion.',
      body: `
        <div class="bx-tabs" data-tabs>
          <button class="bx-tab on" data-tab="email">Email</button>
          <button class="bx-tab" data-tab="link">Copy link</button>
          <button class="bx-tab" data-tab="csv">Bulk · CSV</button>
        </div>
        <div data-tab-panel="email">
          <div class="bx-field"><label>Client email</label><input type="email" placeholder="client@example.com" /></div>
          <div class="bx-field"><label>Personal note</label><textarea placeholder="Looking forward to working with you…"></textarea></div>
        </div>
        <div data-tab-panel="link" style="display:none">
          <div class="bx-field"><label>Shareable link · valid 7 days</label><input value="binectics.com/i/sarah-o/abcd1234" readonly /></div>
          <div class="bx-callout info"><span class="ico"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 16v-4M12 8h.01"/></svg></span><span class="t">Anyone with this link can book a first session. Revoke any time from settings.</span></div>
        </div>
        <div data-tab-panel="csv" style="display:none">
          <div class="bx-field"><label>CSV file</label><input type="file" accept=".csv" /></div>
          <div class="bx-field"><span class="hint">Columns: name, email, phone (optional). We email each one a unique link.</span></div>
        </div>`,
      foot: `
        <button class="bx-btn ghost" data-close>Cancel</button>
        <button class="bx-btn primary" data-action="invite">Send invite</button>`
    }),

    'block-off-time': () => ({
      title: 'Block off time',
      sub: "Mark yourself unavailable. Existing bookings won't be cancelled.",
      body: `
        <div class="bx-picker" data-radio>
          <div class="bx-opt on" data-value="hours">
            <span class="radio"></span>
            <div><div class="t">Few hours</div><div class="s">Same day, partial day · e.g. doctor's appointment</div></div>
          </div>
          <div class="bx-opt" data-value="day">
            <span class="radio"></span>
            <div><div class="t">Full day(s)</div><div class="s">Travel · personal · sick</div></div>
          </div>
          <div class="bx-opt" data-value="recurring">
            <span class="radio"></span>
            <div><div class="t">Recurring</div><div class="s">Every Tuesday 12–2 · school run · standing commitment</div></div>
          </div>
        </div>
        <div class="bx-row-2">
          <div class="bx-field"><label>Starts</label><input type="datetime-local" value="2026-05-28T12:00" /></div>
          <div class="bx-field"><label>Ends</label><input type="datetime-local" value="2026-05-28T14:00" /></div>
        </div>
        <div class="bx-field"><label>Reason (private)</label><input placeholder="e.g. Dentist" /></div>`,
      foot: `
        <button class="bx-btn ghost" data-close>Cancel</button>
        <button class="bx-btn primary" data-action="block">Block this time</button>`
    }),

    'new-package': () => ({
      title: 'New package',
      sub: 'Members buy packages on your profile. You can edit anything later.',
      body: `
        <div class="bx-field"><label>Package name</label><input placeholder="Strength · 12-pack" /></div>
        <div class="bx-row-2">
          <div class="bx-field"><label>Sessions included</label><input type="number" value="12" /></div>
          <div class="bx-field"><label>Price</label><input value="R 14,400" /></div>
        </div>
        <div class="bx-row-2">
          <div class="bx-field"><label>Window</label><select><option>8 weeks</option><option>12 weeks</option><option>16 weeks</option><option>No expiry</option></select></div>
          <div class="bx-field"><label>Format</label><select><option>In-person</option><option>Online video</option><option>Programming only</option></select></div>
        </div>
        <div class="bx-field"><label>What's included</label><textarea placeholder="Custom program · weekly check-in · …"></textarea></div>`,
      foot: `
        <button class="bx-btn ghost" data-close>Cancel</button>
        <button class="bx-btn primary" data-action="create-pkg">Save package</button>`
    }),

    'add-staff': () => ({
      title: 'Add staff',
      sub: 'Send them an invite. They sign in and pick a password.',
      body: `
        <div class="bx-row-2">
          <div class="bx-field"><label>First name</label><input /></div>
          <div class="bx-field"><label>Last name</label><input /></div>
        </div>
        <div class="bx-field"><label>Email</label><input type="email" placeholder="coach@ironlab.co.za" /></div>
        <div class="bx-field">
          <label>Role</label>
          <select>
            <option>Coach · standard scope</option>
            <option>Coach · manager scope</option>
            <option>Front desk</option>
            <option>Owner (full access)</option>
          </select>
        </div>
        <div class="bx-field"><label>Locations they work at</label><select multiple style="height: 80px;"><option selected>Sea Point</option><option>Foreshore</option><option>Camps Bay</option><option>Woodstock</option></select></div>`,
      foot: `
        <button class="bx-btn ghost" data-close>Cancel</button>
        <button class="bx-btn primary" data-action="invite-staff">Send invite</button>`
    }),

    'add-location': () => ({
      title: 'Add a new location',
      sub: "We'll verify the address and your business documents. Usually under 48h.",
      body: `
        <div class="bx-field"><label>Location name</label><input placeholder="Iron Lab · Stellenbosch" /></div>
        <div class="bx-field"><label>Street address</label><input placeholder="14 Dorp Street" /></div>
        <div class="bx-row-2">
          <div class="bx-field"><label>City</label><input value="Stellenbosch" /></div>
          <div class="bx-field"><label>Postal code</label><input value="7600" /></div>
        </div>
        <div class="bx-field"><label>Floor area · m²</label><input type="number" placeholder="540" /></div>
        <div class="bx-callout info"><span class="ico"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 16v-4M12 8h.01"/></svg></span><span class="t">Next: amenities, photos, opening hours. Don't worry if not all ready — you can save as draft.</span></div>`,
      foot: `
        <button class="bx-btn ghost" data-close>Save as draft</button>
        <button class="bx-btn primary" data-action="add-location">Next → amenities</button>`
    }),

    'add-bank-account': () => ({
      title: 'Add bank account',
      sub: "Where Binectics sends your payouts. We don't store the account number — only your gateway does.",
      body: `
        <div class="bx-field">
          <label>Gateway</label>
          <select>
            <option>Paystack · ZAR · NGN · GHS · KES</option>
            <option>Stripe · USD · EUR · GBP</option>
            <option>Flutterwave · NGN · KES · UGX</option>
            <option>Razorpay · INR</option>
          </select>
        </div>
        <div class="bx-row-2">
          <div class="bx-field"><label>Bank</label><select>
            <optgroup label="South Africa">
              <option>ABSA</option>
              <option>Standard Bank</option>
              <option>FNB</option>
              <option>Capitec</option>
              <option>Nedbank</option>
              <option>Discovery Bank</option>
              <option>TymeBank</option>
            </optgroup>
            <optgroup label="Nigeria">
              <option>Guaranty Trust Bank (GTBank)</option>
              <option>Access Bank</option>
              <option>Zenith Bank</option>
              <option>First Bank of Nigeria</option>
              <option>United Bank for Africa (UBA)</option>
              <option>Stanbic IBTC</option>
              <option>Wema Bank (ALAT)</option>
              <option>Kuda</option>
              <option>Opay</option>
              <option>PalmPay</option>
            </optgroup>
            <optgroup label="Kenya">
              <option>Equity Bank</option>
              <option>KCB</option>
              <option>Co-op Bank</option>
              <option>NCBA</option>
              <option>M-Pesa wallet</option>
            </optgroup>
            <optgroup label="Ghana">
              <option>GCB Bank</option>
              <option>Ecobank Ghana</option>
              <option>Absa Ghana</option>
              <option>MTN MoMo</option>
            </optgroup>
            <optgroup label="Uganda · Tanzania · Rwanda">
              <option>Stanbic Uganda</option>
              <option>CRDB Tanzania</option>
              <option>Bank of Kigali</option>
            </optgroup>
          </select></div>
          <div class="bx-field"><label>Account type</label><select><option>Cheque / current</option><option>Savings</option><option>Business</option><option>Mobile wallet</option></select></div>
        </div>
        <div class="bx-field"><label>Account number</label><input placeholder="0000 0000 0000" /></div>
        <div class="bx-callout warn"><span class="ico"><svg viewBox="0 0 24 24"><path d="M10.3 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><path d="M12 9v4M12 17h.01"/></svg></span><span class="t">Set as <strong>primary</strong> and all future payouts route here. Existing in-flight payouts complete to the old account.</span></div>`,
      foot: `
        <button class="bx-btn ghost" data-close>Cancel</button>
        <button class="bx-btn primary" data-action="add-bank">Verify with gateway →</button>`
    }),

    'pair-device': () => ({
      title: 'Pair a new device',
      sub: 'Open the Binectics Kiosk app on the iPad and enter this code.',
      body: `
        <div style="text-align: center; padding: 24px 0;">
          <div style="font-family: ui-monospace, monospace; font-size: 48px; letter-spacing: 0.18em; font-weight: 600; color: var(--ink); font-variant-numeric: tabular-nums;">4 8 2 1</div>
          <div style="font-family: ui-monospace, monospace; font-size: 11px; color: var(--fg-3, #75716b); text-transform: uppercase; letter-spacing: 0.06em; margin-top: 8px;">expires in 9:48</div>
        </div>
        <div class="bx-field"><label>Device label</label><input placeholder="Sea Point · entry kiosk" /></div>
        <div class="bx-field">
          <label>Location</label>
          <select><option>Sea Point</option><option>Foreshore</option><option>Camps Bay</option><option>Woodstock</option></select>
        </div>
        <div class="bx-callout info"><span class="ico"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 16v-4M12 8h.01"/></svg></span><span class="t">The code rotates every 10 min. If it expires, just reopen this modal.</span></div>`,
      foot: `
        <button class="bx-btn ghost" data-close>Cancel</button>
        <button class="bx-btn primary" data-action="wait-pair">Waiting for device…</button>`
    }),

    'approve-listing': () => ({
      title: 'Approve listing',
      sub: 'This sends the verified badge to the provider and unlocks them in marketplace search.',
      body: `
        <div class="bx-field">
          <label>Verified for</label>
          <select><option>24 months (standard)</option><option>12 months (probationary)</option><option>36 months (gold)</option></select>
        </div>
        <div class="bx-field"><label>Reviewer notes (internal)</label><textarea placeholder="Documents checked: NSCA-CSCS, public liability, ID. All current."></textarea></div>
        <div class="bx-callout"><span class="ico"><svg viewBox="0 0 24 24"><path d="M9 12l2 2 4-4"/><circle cx="12" cy="12" r="9"/></svg></span><span class="t">Logged in audit log under your name. Provider gets an email within 5 minutes.</span></div>`,
      foot: `
        <button class="bx-btn ghost" data-close>Cancel</button>
        <button class="bx-btn signal" data-action="approve">Approve →</button>`
    }),

    'reject-listing': () => ({
      title: 'Reject listing',
      sub: 'The provider gets a written reason and 30 days to re-submit.',
      body: `
        <div class="bx-picker" data-radio>
          <div class="bx-opt on" data-value="docs"><span class="radio"></span><div><div class="t">Missing or expired documents</div><div class="s">Most common · provider re-uploads and we re-review</div></div></div>
          <div class="bx-opt" data-value="quality"><span class="radio"></span><div><div class="t">Photos / description quality</div><div class="s">Low-res photos, misleading claims, no business address</div></div></div>
          <div class="bx-opt" data-value="safety"><span class="radio"></span><div><div class="t">Safety concern</div><div class="s">Escalate to senior reviewer · no auto-rejection</div></div></div>
          <div class="bx-opt" data-value="other"><span class="radio"></span><div><div class="t">Other</div></div></div>
        </div>
        <div class="bx-field"><label>Note to provider</label><textarea placeholder="Specific changes needed before re-submission…"></textarea></div>`,
      foot: `
        <button class="bx-btn ghost" data-close>Cancel</button>
        <button class="bx-btn danger" data-action="reject">Send rejection</button>`
    }),

    'confirm': (data) => ({
      title: data.title || 'Are you sure?',
      sub: '',
      body: `
        <p>${data.body || 'This action cannot be undone.'}</p>
        ${data.callout ? `<div class="bx-callout"><span class="ico"><svg viewBox="0 0 24 24"><path d="M10.3 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><path d="M12 9v4M12 17h.01"/></svg></span><span class="t">${data.callout}</span></div>` : ''}`,
      foot: `
        <button class="bx-btn ghost" data-close>Cancel</button>
        <button class="bx-btn ${data.tone || 'danger'}" data-action="confirm">${data.action || 'Confirm'}</button>`
    })
  };

  // ---------- RENDER ----------
  let activeScrim = null;

  function open(id, dataAttrs) {
    if (!TEMPLATES[id]) { console.warn('No modal:', id); return; }

    // Build params for dynamic templates from data-confirm-* attrs
    const data = {
      title: dataAttrs?.title,
      body: dataAttrs?.body,
      callout: dataAttrs?.callout,
      tone: dataAttrs?.tone,
      action: dataAttrs?.action,
    };
    const tpl = TEMPLATES[id](data);

    const scrim = document.createElement('div');
    scrim.className = 'bx-scrim';
    scrim.innerHTML = `
      <div class="bx-modal ${tpl.wide ? 'wide' : ''}" role="dialog" aria-modal="true">
        <div class="bx-modal-head">
          <div>
            <h3>${tpl.title}</h3>
            ${tpl.sub ? `<div class="sub">${tpl.sub}</div>` : ''}
          </div>
          <span class="bx-x" data-close><svg viewBox="0 0 24 24"><path d="M18 6L6 18M6 6l12 12"/></svg></span>
        </div>
        <div class="bx-modal-body">${tpl.body}</div>
        <div class="bx-modal-foot">${tpl.foot}</div>
      </div>`;
    document.body.appendChild(scrim);
    requestAnimationFrame(() => scrim.classList.add('on'));
    activeScrim = scrim;

    // Wire up close
    scrim.addEventListener('click', e => { if (e.target === scrim) close(); });
    scrim.querySelectorAll('[data-close]').forEach(el => el.addEventListener('click', () => close()));

    // Radio pickers
    scrim.querySelectorAll('[data-radio]').forEach(grp => {
      grp.querySelectorAll('.bx-opt').forEach(opt => {
        opt.addEventListener('click', () => {
          grp.querySelectorAll('.bx-opt').forEach(x => x.classList.remove('on'));
          opt.classList.add('on');
        });
      });
    });

    // Tabs
    scrim.querySelectorAll('[data-tabs]').forEach(grp => {
      const panels = scrim.querySelectorAll('[data-tab-panel]');
      grp.querySelectorAll('.bx-tab').forEach(t => {
        t.addEventListener('click', () => {
          grp.querySelectorAll('.bx-tab').forEach(x => x.classList.remove('on'));
          t.classList.add('on');
          panels.forEach(p => p.style.display = p.dataset.tabPanel === t.dataset.tab ? '' : 'none');
        });
      });
    });

    // Action buttons → toast + close
    scrim.querySelectorAll('[data-action]').forEach(btn => {
      btn.addEventListener('click', () => {
        const action = btn.dataset.action;
        // Special: 'create' (new-plan) routes to the right builder based on selected type
        if (action === 'create') {
          const selected = scrim.querySelector('[data-radio] .bx-opt.on');
          const type = selected?.dataset.value || 'strength';
          const routes = {
            'strength': 'plan-builder.html',
            'meal': 'dietitian-meals.html',
            'membership': 'gym-plans.html',
            'program': 'plan-builder.html',
          };
          close();
          window.location.href = routes[type];
          return;
        }
        const msg = ACTION_TOAST[action] || { text: 'Done.', tone: 'success' };
        close();
        toast(msg.text, msg);
      });
    });
  }

  function close() {
    if (!activeScrim) return;
    activeScrim.classList.remove('on');
    const el = activeScrim;
    activeScrim = null;
    setTimeout(() => el.remove(), 220);
  }

  // ---------- TOAST ----------
  const ACTION_TOAST = {
    'create-flag':  { text: 'Flag created · live in 5s', tone: 'success' },
    'create':       { text: 'New plan started · open builder',   tone: 'success', action: 'Open' },
    'book':         { text: 'Session booked · client notified',  tone: 'success', action: 'Undo' },
    'invite':       { text: 'Invite sent',                       tone: 'success' },
    'block':        { text: 'Time blocked off',                  tone: 'default', action: 'Undo' },
    'create-pkg':   { text: 'Package saved · now live on profile', tone: 'success' },
    'invite-staff': { text: 'Staff invite sent',                 tone: 'success' },
    'add-location': { text: 'Location saved as draft',           tone: 'default' },
    'add-bank':     { text: 'Bank account verification started', tone: 'default' },
    'wait-pair':    { text: 'Listening for kiosk…',              tone: 'default' },
    'approve':      { text: 'Listing approved · provider notified', tone: 'success' },
    'reject':       { text: 'Listing rejected · message sent',   tone: 'danger' },
    'confirm':      { text: 'Done.',                             tone: 'success' },
  };

  let toastStack = null;
  function toast(text, opts = {}) {
    if (!toastStack) {
      toastStack = document.createElement('div');
      toastStack.className = 'bx-toast-stack';
      document.body.appendChild(toastStack);
    }
    const t = document.createElement('div');
    t.className = 'bx-toast' + (opts.tone && opts.tone !== 'default' ? ' ' + opts.tone : '');
    t.innerHTML = `
      <span class="ico"><svg viewBox="0 0 24 24"><path d="M5 12l5 5L20 7"/></svg></span>
      <span style="flex:1">${text}</span>
      ${opts.action ? `<span class="undo">${opts.action}</span>` : ''}
    `;
    toastStack.appendChild(t);
    requestAnimationFrame(() => t.classList.add('on'));
    setTimeout(() => { t.classList.remove('on'); setTimeout(() => t.remove(), 250); }, 4000);
  }

  // ---------- AUTOWIRE ----------
  function autowire() {
    document.querySelectorAll('[data-modal]').forEach(el => {
      if (el.dataset.bxBound) return;
      el.dataset.bxBound = '1';
      el.style.cursor = 'pointer';
      el.addEventListener('click', e => {
        e.preventDefault();
        const id = el.dataset.modal;
        const dataAttrs = {
          title:   el.dataset.confirmTitle,
          body:    el.dataset.confirmBody,
          callout: el.dataset.confirmCallout,
          tone:    el.dataset.confirmTone,
          action:  el.dataset.confirmAction,
        };
        open(id, dataAttrs);
      });
    });
    // Help icon → toast with help-center link
    document.querySelectorAll('[data-help]').forEach(el => {
      if (el.dataset.bxBound) return;
      el.dataset.bxBound = '1';
      el.style.cursor = 'pointer';
      el.addEventListener('click', e => {
        e.preventDefault();
        open('confirm', {
          title: 'Help &amp; support',
          body: 'Search the help center, message us in-app, or email <strong>help@binectics.com</strong>. Average first-reply is 1h 38m.',
          action: 'Open help center',
          tone: 'primary',
        });
      });
    });
    // Search icon → cmd-K toast (placeholder)
    document.querySelectorAll('[data-search]').forEach(el => {
      if (el.dataset.bxBound) return;
      el.dataset.bxBound = '1';
      el.style.cursor = 'pointer';
      el.addEventListener('click', e => {
        e.preventDefault();
        toast('Search · press ⌘K to open the command bar', { tone: 'default' });
      });
    });
    // Export icons → trigger download-ish toast
    document.querySelectorAll('[data-export]').forEach(el => {
      if (el.dataset.bxBound) return;
      el.dataset.bxBound = '1';
      el.style.cursor = 'pointer';
      el.addEventListener('click', e => {
        e.preventDefault();
        toast('Preparing export · we\'ll email when ready', { tone: 'default', action: 'Cancel' });
      });
    });
  }

  // ESC key
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && activeScrim) close(); });

  // Init on DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', autowire);
  } else {
    autowire();
  }

  // Expose
  window.Modals = { open, close, toast, autowire };

})();


/* ─────────────────────────────────────────────
   Binectics modals.js · Phase 1 Track B extensions
   Command bar (⌘K) · Notifications drawer · Image lightbox
   ─────────────────────────────────────────── */
(function () {
  const css = `
  /* COMMAND BAR */
  .bx-cmd { position: fixed; inset: 0; background: oklch(0 0 0 / 0.45); display: none; align-items: flex-start; justify-content: center; z-index: 9998; padding-top: 120px; backdrop-filter: blur(2px); }
  .bx-cmd.on { display: flex; }
  .bx-cmd-box { background: var(--bg, #fff); border-radius: 14px; width: 100%; max-width: 580px; max-height: 64vh; overflow: hidden; box-shadow: 0 20px 60px oklch(0 0 0 / 0.20); display: flex; flex-direction: column; }
  .bx-cmd-input { display: flex; align-items: center; gap: 10px; padding: 14px 18px; border-bottom: 1px solid var(--border, #ebe7e1); }
  .bx-cmd-input svg { width: 16px; height: 16px; stroke: var(--fg-3, #75716b); fill: none; stroke-width: 1.6; flex-shrink: 0; }
  .bx-cmd-input input { flex: 1; border: 0; background: transparent; font: inherit; font-size: 15px; color: var(--ink); outline: none; }
  .bx-cmd-input .kbd { font-family: ui-monospace, monospace; font-size: 10.5px; padding: 3px 8px; border: 1px solid var(--border, #ebe7e1); border-radius: 4px; color: var(--fg-3, #75716b); }
  .bx-cmd-list { overflow-y: auto; padding: 6px 0 10px; }
  .bx-cmd-group { padding: 8px 0; }
  .bx-cmd-group .lbl { padding: 4px 18px 6px; font-family: ui-monospace, monospace; font-size: 9.5px; color: var(--fg-4, #a09c95); text-transform: uppercase; letter-spacing: 0.06em; }
  .bx-cmd-item { padding: 9px 18px; display: flex; gap: 12px; align-items: center; cursor: pointer; }
  .bx-cmd-item:hover, .bx-cmd-item.sel { background: var(--bg-2, #f4f0e9); }
  .bx-cmd-item .icn { width: 22px; height: 22px; border-radius: 5px; background: var(--bg-2, #f4f0e9); display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
  .bx-cmd-item .icn svg { width: 12px; height: 12px; stroke: var(--ink); fill: none; stroke-width: 1.6; }
  .bx-cmd-item .t { flex: 1; font-size: 13.5px; color: var(--ink); font-weight: 500; }
  .bx-cmd-item .s { font-family: ui-monospace, monospace; font-size: 10.5px; color: var(--fg-3, #75716b); text-transform: uppercase; letter-spacing: 0.04em; }
  .bx-cmd-foot { padding: 8px 18px; border-top: 1px solid var(--border, #ebe7e1); font-family: ui-monospace, monospace; font-size: 10px; color: var(--fg-3, #75716b); display: flex; justify-content: space-between; text-transform: uppercase; letter-spacing: 0.04em; }
  .bx-cmd-foot .keys { display: flex; gap: 14px; }

  /* NOTIFICATIONS DRAWER */
  .bx-drawer-scrim { position: fixed; inset: 0; background: oklch(0 0 0 / 0.25); display: none; z-index: 9997; }
  .bx-drawer-scrim.on { display: block; }
  .bx-drawer { position: fixed; top: 0; right: 0; bottom: 0; width: 360px; max-width: 92vw; background: var(--bg, #fff); box-shadow: -8px 0 24px oklch(0 0 0 / 0.10); transform: translateX(100%); transition: transform 0.22s cubic-bezier(.2,.7,.2,1); z-index: 9999; display: flex; flex-direction: column; }
  .bx-drawer.on { transform: translateX(0); }
  .bx-drawer-head { padding: 16px 20px; border-bottom: 1px solid var(--border, #ebe7e1); display: flex; justify-content: space-between; align-items: center; }
  .bx-drawer-head h3 { font-size: 15px; font-weight: 500; color: var(--ink); margin: 0; display: flex; gap: 8px; align-items: center; }
  .bx-drawer-head .n { background: var(--ink); color: var(--bg); font-family: ui-monospace, monospace; font-size: 10px; padding: 2px 7px; border-radius: 999px; }
  .bx-drawer-tabs { display: flex; gap: 2px; padding: 8px 16px; border-bottom: 1px solid var(--border, #ebe7e1); }
  .bx-drawer-tab { padding: 5px 10px; font-family: ui-monospace, monospace; font-size: 10.5px; color: var(--fg-3, #75716b); text-transform: uppercase; letter-spacing: 0.04em; background: transparent; border: 0; border-radius: 4px; cursor: pointer; }
  .bx-drawer-tab.on { background: var(--bg-2, #f4f0e9); color: var(--ink); }
  .bx-drawer-list { flex: 1; overflow-y: auto; }
  .bx-notif { padding: 13px 18px; border-bottom: 1px solid var(--border, #ebe7e1); display: flex; gap: 11px; align-items: flex-start; cursor: pointer; }
  .bx-notif:hover { background: var(--bg-2, #f4f0e9); }
  .bx-notif.unread { background: oklch(0.97 0.013 75); position: relative; }
  .bx-notif.unread::before { content: ''; position: absolute; left: 6px; top: 50%; width: 5px; height: 5px; background: var(--signal); border-radius: 50%; transform: translateY(-50%); }
  .bx-notif .icn { width: 28px; height: 28px; border-radius: 6px; background: var(--bg-2, #f4f0e9); display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
  .bx-notif .icn svg { width: 14px; height: 14px; stroke: var(--ink); fill: none; stroke-width: 1.6; }
  .bx-notif.danger .icn { background: var(--danger-soft, #f9e1de); }
  .bx-notif.danger .icn svg { stroke: var(--danger); }
  .bx-notif.signal .icn { background: var(--signal-soft, #d9efd5); }
  .bx-notif.signal .icn svg { stroke: var(--signal-ink); }
  .bx-notif .body { flex: 1; min-width: 0; }
  .bx-notif .t { font-size: 13px; color: var(--ink); line-height: 1.45; }
  .bx-notif .t strong { font-weight: 500; }
  .bx-notif .ts { font-family: ui-monospace, monospace; font-size: 10.5px; color: var(--fg-3, #75716b); margin-top: 3px; }
  .bx-drawer-foot { padding: 12px 18px; border-top: 1px solid var(--border, #ebe7e1); display: flex; gap: 8px; }
  .bx-drawer-foot button { flex: 1; font: inherit; font-size: 12.5px; padding: 8px; border-radius: 6px; cursor: pointer; border: 1px solid var(--border, #ebe7e1); background: var(--bg); color: var(--ink); }

  /* LIGHTBOX */
  .bx-lb { position: fixed; inset: 0; background: oklch(0.08 0.005 80 / 0.95); display: none; align-items: center; justify-content: center; z-index: 10001; padding: 40px; backdrop-filter: blur(4px); }
  .bx-lb.on { display: flex; }
  .bx-lb-img { max-width: 90vw; max-height: 84vh; border-radius: 8px; background: var(--bg-3); display: flex; align-items: center; justify-content: center; color: var(--fg-3); font-family: ui-monospace, monospace; font-size: 12px; min-width: 320px; min-height: 240px; }
  .bx-lb-img img { max-width: 100%; max-height: 84vh; border-radius: 8px; display: block; }
  .bx-lb-x { position: absolute; top: 24px; right: 28px; color: oklch(0.7 0.005 85); cursor: pointer; width: 36px; height: 36px; border-radius: 50%; background: oklch(0 0 0 / 0.4); display: flex; align-items: center; justify-content: center; }
  .bx-lb-x svg { width: 18px; height: 18px; stroke: currentColor; fill: none; stroke-width: 1.8; }
  .bx-lb-cap { position: absolute; bottom: 28px; left: 50%; transform: translateX(-50%); color: oklch(0.78 0.005 85); font-family: ui-monospace, monospace; font-size: 11px; text-transform: uppercase; letter-spacing: 0.06em; }
  `;
  const style = document.createElement('style'); style.textContent = css; document.head.appendChild(style);

  // ─── COMMAND BAR ───
  const cmdActions = [
    { group: 'Navigate', icon: 'M3 9h18M9 21V9', label: 'Marketplace', meta: 'G M', href: 'marketplace.html' },
    { group: 'Navigate', icon: 'M3 9h18M9 21V9', label: 'My bookings', meta: 'G B', href: 'my-bookings.html' },
    { group: 'Navigate', icon: 'M3 9h18M9 21V9', label: 'Messages', meta: 'G I', href: 'messages.html' },
    { group: 'Navigate', icon: 'M3 9h18M9 21V9', label: 'Settings', meta: 'G S', href: 'settings.html' },
    { group: 'Actions', icon: 'M12 5v14M5 12h14', label: 'New plan', meta: '⌘ N', modal: 'new-plan' },
    { group: 'Actions', icon: 'M12 5v14M5 12h14', label: 'Book session', meta: '⌘ B', modal: 'book-session' },
    { group: 'Actions', icon: 'M12 5v14M5 12h14', label: 'Invite client', meta: '', modal: 'invite-client' },
    { group: 'Actions', icon: 'M12 5v14M5 12h14', label: 'Block off time', meta: '', modal: 'block-off-time' },
    { group: 'Help', icon: 'M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3M12 17h.01', label: 'Help center', meta: '', href: 'help.html' },
    { group: 'Help', icon: 'M3 21l1.6-4.7A9 9 0 1 1 12 21z', label: 'Contact support', meta: '', href: 'help.html' },
  ];
  let cmdBox, cmdInput, cmdList;
  let cmdSel = 0;

  function openCmd() {
    if (!cmdBox) {
      cmdBox = document.createElement('div');
      cmdBox.className = 'bx-cmd';
      cmdBox.innerHTML = `
        <div class="bx-cmd-box">
          <div class="bx-cmd-input">
            <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>
            <input placeholder="Search · jump · run an action…" autofocus />
            <span class="kbd">esc</span>
          </div>
          <div class="bx-cmd-list"></div>
          <div class="bx-cmd-foot">
            <div class="keys"><span>↑↓ navigate</span><span>↵ select</span></div>
            <span>Binectics</span>
          </div>
        </div>`;
      document.body.appendChild(cmdBox);
      cmdBox.addEventListener('click', e => { if (e.target === cmdBox) closeCmd(); });
      cmdInput = cmdBox.querySelector('input');
      cmdList = cmdBox.querySelector('.bx-cmd-list');
      cmdInput.addEventListener('input', renderCmd);
      cmdInput.addEventListener('keydown', e => {
        const items = cmdList.querySelectorAll('.bx-cmd-item');
        if (e.key === 'ArrowDown') { e.preventDefault(); cmdSel = (cmdSel + 1) % items.length; updateSel(items); }
        else if (e.key === 'ArrowUp') { e.preventDefault(); cmdSel = (cmdSel - 1 + items.length) % items.length; updateSel(items); }
        else if (e.key === 'Enter') { e.preventDefault(); items[cmdSel]?.click(); }
      });
      renderCmd();
    }
    requestAnimationFrame(() => { cmdBox.classList.add('on'); cmdInput.focus(); cmdInput.value = ''; renderCmd(); });
  }
  function closeCmd() { if (cmdBox) cmdBox.classList.remove('on'); }
  function updateSel(items) { items.forEach((it, i) => it.classList.toggle('sel', i === cmdSel)); items[cmdSel]?.scrollIntoView({block:'nearest'}); }
  function renderCmd() {
    const q = (cmdInput.value || '').toLowerCase();
    const matches = cmdActions.filter(a => a.label.toLowerCase().includes(q) || a.group.toLowerCase().includes(q));
    const grouped = {};
    matches.forEach(m => { if (!grouped[m.group]) grouped[m.group] = []; grouped[m.group].push(m); });
    cmdList.innerHTML = Object.entries(grouped).map(([g, items]) => `
      <div class="bx-cmd-group">
        <div class="lbl">${g}</div>
        ${items.map(it => `<div class="bx-cmd-item" data-href="${it.href||''}" data-modal="${it.modal||''}"><span class="icn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="${it.icon}"/></svg></span><span class="t">${it.label}</span><span class="s">${it.meta}</span></div>`).join('')}
      </div>`).join('') || '<div class="bx-cmd-group"><div class="lbl">No matches</div></div>';
    cmdList.querySelectorAll('.bx-cmd-item').forEach(it => {
      it.addEventListener('click', () => {
        closeCmd();
        if (it.dataset.href) location.href = it.dataset.href;
        else if (it.dataset.modal) setTimeout(() => window.Modals.open(it.dataset.modal), 100);
      });
    });
    cmdSel = 0;
    updateSel(cmdList.querySelectorAll('.bx-cmd-item'));
  }

  // ─── NOTIFICATIONS DRAWER ───
  let drawer, drawerScrim;
  const sampleNotifs = [
    { kind: 'signal', t: '<strong>Sarah confirmed</strong> your session for Wed 08:30', ts: '8m ago', unread: true },
    { kind: 'danger', t: '<strong>Payment failed</strong> · VISA •••• 4421 · Iron Lab subscription', ts: '42m ago', unread: true },
    { kind: '', t: 'Linda Mokoena hit a <strong>30-day streak</strong> · Sea Point', ts: '2h ago', unread: false },
    { kind: 'signal', t: 'Weekly payout · <strong>R 84,200</strong> on the way to ABSA', ts: 'Tue 09:00', unread: false },
    { kind: '', t: 'Dr Nadia Hassan completed <strong>Folake A.</strong>\'s intake review', ts: 'Yesterday', unread: false },
    { kind: '', t: 'Your insurance certificate expires in <strong>22 days</strong>', ts: '2 days ago', unread: false },
  ];

  function openDrawer() {
    if (!drawer) {
      drawerScrim = document.createElement('div'); drawerScrim.className = 'bx-drawer-scrim';
      drawer = document.createElement('aside'); drawer.className = 'bx-drawer';
      drawer.innerHTML = `
        <div class="bx-drawer-head"><h3>Notifications <span class="n">${sampleNotifs.filter(n=>n.unread).length}</span></h3><span class="bx-x" data-drawer-close style="cursor:pointer; padding:6px;"><svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="1.7"><path d="M18 6L6 18M6 6l12 12"/></svg></span></div>
        <div class="bx-drawer-tabs"><button class="bx-drawer-tab on">All</button><button class="bx-drawer-tab">Bookings</button><button class="bx-drawer-tab">Payments</button><button class="bx-drawer-tab">Mentions</button></div>
        <div class="bx-drawer-list">${sampleNotifs.map(n => `
          <div class="bx-notif ${n.kind} ${n.unread?'unread':''}"><span class="icn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/></svg></span><div class="body"><div class="t">${n.t}</div><div class="ts">${n.ts}</div></div></div>`).join('')}</div>
        <div class="bx-drawer-foot"><button id="bx-mark-all">Mark all read</button><button>Notification settings</button></div>`;
      document.body.appendChild(drawerScrim);
      document.body.appendChild(drawer);
      drawerScrim.addEventListener('click', closeDrawer);
      drawer.querySelector('[data-drawer-close]').addEventListener('click', closeDrawer);
      drawer.querySelectorAll('.bx-drawer-tab').forEach(t => t.addEventListener('click', () => {
        drawer.querySelectorAll('.bx-drawer-tab').forEach(x => x.classList.remove('on'));
        t.classList.add('on');
      }));
      drawer.querySelector('#bx-mark-all').addEventListener('click', () => {
        drawer.querySelectorAll('.bx-notif.unread').forEach(n => n.classList.remove('unread'));
        drawer.querySelector('.bx-drawer-head .n').textContent = '0';
        if (window.Modals) window.Modals.toast('Marked all read', { tone: 'default' });
      });
    }
    drawerScrim.classList.add('on');
    requestAnimationFrame(() => drawer.classList.add('on'));
  }
  function closeDrawer() { if (drawer) { drawer.classList.remove('on'); drawerScrim.classList.remove('on'); } }

  // ─── IMAGE LIGHTBOX ───
  let lb;
  function openLightbox(src, caption) {
    if (!lb) {
      lb = document.createElement('div'); lb.className = 'bx-lb';
      lb.innerHTML = `<span class="bx-lb-x" data-lb-close><svg viewBox="0 0 24 24"><path d="M18 6L6 18M6 6l12 12"/></svg></span><div class="bx-lb-img"></div><div class="bx-lb-cap"></div>`;
      document.body.appendChild(lb);
      lb.addEventListener('click', e => { if (e.target === lb || e.target.closest('[data-lb-close]')) closeLightbox(); });
    }
    const imgWrap = lb.querySelector('.bx-lb-img');
    imgWrap.innerHTML = src ? `<img src="${src}" alt="" />` : 'Image preview';
    lb.querySelector('.bx-lb-cap').textContent = caption || '';
    lb.classList.add('on');
  }
  function closeLightbox() { if (lb) lb.classList.remove('on'); }

  // ─── GLOBAL HOTKEYS + WIRING ───
  document.addEventListener('keydown', e => {
    if ((e.metaKey || e.ctrlKey) && e.key === 'k') { e.preventDefault(); openCmd(); }
    else if (e.key === 'Escape') { closeCmd(); closeDrawer(); closeLightbox(); }
  });

  // Auto-bind anything with data-cmdk, data-notifications, data-lightbox
  function bind() {
    document.querySelectorAll('[data-cmdk]').forEach(el => {
      if (el.dataset.bxBoundCmdk) return;
      el.dataset.bxBoundCmdk = '1';
      el.style.cursor = 'pointer';
      el.addEventListener('click', e => { e.preventDefault(); openCmd(); });
    });
    document.querySelectorAll('[data-notifications]').forEach(el => {
      if (el.dataset.bxBoundNotif) return;
      el.dataset.bxBoundNotif = '1';
      el.style.cursor = 'pointer';
      el.addEventListener('click', e => { e.preventDefault(); openDrawer(); });
    });
    document.querySelectorAll('[data-lightbox]').forEach(el => {
      if (el.dataset.bxBoundLb) return;
      el.dataset.bxBoundLb = '1';
      el.style.cursor = 'pointer';
      el.addEventListener('click', e => { e.preventDefault(); openLightbox(el.dataset.lightbox, el.dataset.lightboxCaption); });
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', bind); else bind();

  // Expose & also override the existing search/help handler in modals.js so ⌘K opens the cmd bar instead of the toast
  window.Modals = Object.assign(window.Modals || {}, { openCmd, openDrawer, openLightbox, bindB: bind });
})();
