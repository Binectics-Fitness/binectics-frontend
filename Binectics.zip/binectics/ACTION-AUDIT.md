# Action audit — buttons that need real behavior

**Scope:** 28 dashboard surfaces (gym, trainer, dietitian, admin and their sub-pages).
**Found:** 166 unwired action buttons across 97 unique labels.

Most are inert by design (filter pills, time-range toggles) — they look like working UI but go nowhere. This document groups them by what *kind* of behavior they need, so we can build the right primitives once and reuse.

---

## 1 · Form/modal-worthy actions (priority)

These create or significantly mutate data. They should open a real modal or full screen.

### Across most dashboards
- **+ New plan** (3×) — meal plan / strength plan / membership plan creation → modal with type picker → routes to plan-builder.html or meal builder
- **+ New flag** (admin-flags) — feature flag creation modal
- **+ New protocol** (dietitian-protocols) — protocol builder full-screen
- **+ New class** / **+ New session** / **+ New booking** — scheduling modal
- **+ New location** (gym-locations) — multi-step wizard (address → photos → amenities → staff)
- **+ Add member / + Invite client** — invite modal (email / link / bulk CSV)
- **+ Pair new device** (gym-devices) — QR-pair wizard
- **+ New package** (trainer-packages) — pricing + entitlements modal
- **+ New bank account** (gym-payouts) — KYC flow
- **Open new country** (admin-countries) — country-launch checklist modal

### Support & moderation
- **Approve / Reject** (admin listings) — needs reject-reason modal
- **Auto-refund** (admin-refunds) — confirmation modal with refund preview
- **Defend** chargeback (admin-refunds) — evidence-upload modal
- **Deny** refund (admin-refunds) — deny-reason modal
- **Suspend / Investigate** user (admin) — destructive-confirm modal
- **Reassign** ticket (admin-tickets) — agent picker modal
- **Reply** (admin-tickets) — inline composer expansion or full-screen
- **Impersonate user** (admin / admin-users) — consent + audit confirmation modal

### Provider & member operations
- **Block off time** (trainer / dietitian dashboards) — date-range picker modal
- **Copy link to book** — toast + clipboard, no modal
- **Manage location** (gym-locations) — drilldown page, not modal
- **Update program** / **Open plan** — link, not modal
- **Intake form / Start consult** (dietitian) — full-screen handoff
- **Review** (8×) — context-dependent: dispute → support.html, listing → admin moderation modal

---

## 2 · Filter / range pills (correct as-is, just JS state)

These are intentionally non-blocking. Need state binding, not modals:

- `7D · 30D · QTD · YTD · Custom` (4 dashboards) → URL query param + chart re-render
- `Filter / Sort / Columns` table toolbars (gym-members, gym-staff) → drawer or popover
- `Export CSV / Export` (admin-users, admin-audit, gym-staff) → toast with download link
- `Compare` (admin-countries) → multi-select mode + comparison drawer

---

## 3 · Card actions (already linked or trivial)

- **View public profile →** trainer/dietitian dashboards — link to `provider.html`
- **Open** booking / ticket / case — link to detail page
- **Check‑in** — link to `checkin.html`
- **Join** (video session) — opens video URL in new tab
- **Notes** — drawer on the same page

---

## 4 · Decorative buttons that should probably go

These appear on dashboards but don't add value as buttons (could be plain labels):

- `Plan` (4× dashboard-trainer) — appears to be a status label, not an action
- `History` (admin-flags) — could be inline timeline instead of separate view
- `Reconcile` (admin-payments) — admin-only nuclear button, hide behind hamburger
- `Force-reissue QR` (admin-tickets) — same, ops-only action

---

## What to build first

The single highest-leverage piece is **a unified action-modal pattern** (already exists in `patterns.html`) wired into:

1. **`+ New plan` → plan-builder.html** (most-clicked across roles)
2. **Approve / Reject** moderation modals (admin queue is the busiest surface)
3. **Suspend / Refund / Investigate** destructive-confirm modal with reason picker
4. **Block off time** date-range modal (every provider uses this weekly)

If we build those 4 modals, **62 of the 166 dead buttons** become functional in one pass.
