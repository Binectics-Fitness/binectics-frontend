# Build plan — close the remaining 28%

**Scope:** everything missing across all areas except the member mobile app (deferred).
**Total scope:** ~64 new surfaces + 6 cross-cutting tracks, organized into 8 phases by dependency + leverage. Phase totals are surface-counts, not days.

---

## Phase 1 · System completeness (foundation)
Items that unblock everything else. Build these first because every surface below benefits.

**Track A — Error & maintenance states (cross-cutting)**
- `error-404.html` — friendly recovery: search, browse marketplace, contact
- `error-500.html` — apologetic, status link, incident ID
- `maintenance.html` — planned downtime page with countdown
- `offline.html` — PWA fallback (cached content + retry)
- `rate-limit.html` — friendly throttle screen with cooldown timer
- `account-locked.html` — security + appeal path
- `session-expired.html` — gentle re-auth nudge

**Track B — System primitives upgrades to `modals.js`**
- ⌘K command bar — global search + actions, lift from `patterns.html`
- Notifications drawer — wire to real per-page state (count, read/unread, mark-all-read toast)
- Image lightbox — wire into provider photos + client progress shots + plan delivery PDFs

**Track C — Empty-state pass**
- Audit every list/table for `0 items` state · standardize: ink illustration mark + one sentence + one CTA
- Targets: my-bookings, messages, calendar, clients-list, all admin queues, search-no-results

→ **9 new pages + 3 primitive upgrades + empty-state pass across ~20 surfaces**

---

## Phase 2 · Auth & lifecycle completion

- `auth-email-verify.html` — landing after email link · success + already-verified + expired states
- `auth-magic-link.html` — magic-link consume page
- `auth-reset-password.html` — token landing form (not the request, the *do-the-reset* page)
- `auth-deleted.html` — "your account is gone, here's what was kept for tax records"
- `auth-2fa-recovery.html` — recovery code entry when phone is lost
- `auth-suspended.html` — different from `account-locked` · for ToS violations · appeal flow

→ **6 new pages**

---

## Phase 3 · Onboarding deep-flows
The current `onboarding.html` is the role-picker shell. Each role needs its own deep flow.

**Track A — Gym owner onboarding (8 steps)**
1. Business details + country
2. Locations (add first one)
3. Membership plans (templates to pick from)
4. KYC docs upload (registration, tax, ID)
5. Payment gateway connect
6. Kiosk hardware pick
7. Staff invite
8. Listing review preview → submit

**Track B — Trainer onboarding (6 steps)**
1. Personal details + city
2. Specializations + format (in-person, online, hybrid)
3. Certifications upload (NSCA, NASM, RYT, etc.)
4. Pricing & availability
5. Payout setup
6. Profile preview → publish

**Track C — Dietitian onboarding (6 steps)**
1. Personal + practice address
2. Licensure docs (RD, MSc, professional indemnity)
3. Specializations + populations
4. Plan templates to seed library
5. Payout setup
6. Profile preview → publish

**Track D — Member onboarding (4 steps, mostly optional)**
1. Goals (lose weight / get strong / run a marathon / etc.)
2. City + preferred providers (gyms vs trainers vs dietitians)
3. Schedule preferences (mornings, evenings, weekends)
4. Skip to marketplace

→ **24 onboarding screens (4 flows × 4–8 steps), can share frame chrome**

---

## Phase 4 · Marketplace & booking gaps

- `marketplace-map.html` — toggle from list to map view · clustered pins · click pin → drawer
- `marketplace-search-results.html` — explicit search results page (when user submits a real query)
- `saved-providers.html` — bookmarked providers · folders / lists
- `marketplace-compare.html` — pick 2–3 providers, side-by-side comparison
- `review-provider.html` — post-session review · star rating + written + photo
- `recurring-booking.html` — set up "every Tuesday at 7am for 12 weeks" · cadence + skip-dates
- `booking-receipt.html` — printable / shareable receipt (separate from `booking-confirmed`)

→ **7 new pages**

---

## Phase 5 · Consumer health & activity (member-facing dashboards)
The "logged-in member" surface beyond bookings + settings.

- `member-home.html` — logged-in landing · next session · streak · weekly summary
- `member-workout-log.html` — adherence ticks against the program · last 30 days
- `member-weight-log.html` — weight + photo trend with chart · sharing toggle per provider
- `member-meal-log.html` — for dietitian clients · macro hit · streak
- `member-streaks.html` — achievements, badges, lifetime stats
- `member-public-profile.html` — what a provider sees about a member (read-only)
- `member-health-metrics.html` — body comp, lifts, mile times — pulled from connected apps
- `member-billing-history.html` — receipts list (separate from settings billing tab)
- `member-help-inbox.html` — member side of `support.html` · their open tickets

→ **9 new pages**

---

## Phase 6 · Gym deep-flows

- `gym-class-detail.html` — single class · roster · waitlist · cancel/edit
- `gym-marketing.html` — share kit · referral codes · discount codes · social templates
- `gym-reviews.html` — moderate, respond, dispute
- `gym-single-member.html` — gym-context single-member detail (different from trainer's `client.html`)
- `gym-single-staff.html` — staff member detail + permissions editor
- `gym-tax-forms.html` — quarterly + annual SARS / IRS forms
- `gym-single-location.html` — single-location drilldown · amenities · photos · schedule

→ **7 new pages**

---

## Phase 7 · Trainer & dietitian deep-flows

**Trainer**
- `trainer-single-session.html` — past session detail · notes · video · attendance
- `trainer-sessions-list.html` — searchable history across all clients
- `trainer-bulk-invite.html` — CSV import flow with preview + error report
- `trainer-tax.html` — annual summary + provisional

**Dietitian**
- `dietitian-pdf-preview.html` — branded PDF as the client sees it (full screen, print-ready)
- `dietitian-feedback.html` — meal-log feedback inbox · photos + reactions
- `dietitian-single-food.html` — food editor (custom foods, macros, brand)
- `dietitian-single-client.html` — dietitian-context drilldown (different from trainer's `client.html`)
- `dietitian-tax.html` — same as trainer-tax but Nadia / Lagos

→ **9 new pages**

---

## Phase 8 · Admin moderation & deep-flows

- `admin-single-listing.html` — drill into one queued listing · evidence · approve/reject inline
- `admin-listing-reject.html` — multi-step reject flow with reason picker + provider message
- `admin-single-dispute.html` — full dispute detail · evidence · timeline · resolution actions
- `admin-dispute-resolve.html` — refund / partial / deny modal (already partly in `support.html`, but as standalone surface)
- `admin-single-fraud.html` — fraud signal detail · pattern · related accounts · actions
- `admin-user-detail.html` — single user · full activity history · sanctions · admin notes
- `admin-impersonate-banner.html` — the banner-wrapped view when admin impersonates
- `admin-single-country.html` — country drilldown · payment rails · regulations · ops contacts
- `admin-single-review.html` — flagged review detail with remove/keep decisions
- `admin-single-payment.html` — single transaction drilldown · gateway trace · refund/dispute actions
- `admin-team-roles.html` — admin team management · who can do what · permissions matrix
- `admin-feature-flag-detail.html` — single flag · rollout history · experiment results · kill switch
- `admin-analytics.html` — the missing analytics dashboard · funnels · retention · GMV
- `admin-compliance.html` — per-country compliance status · KYC stats · regulatory deadlines

→ **14 new pages**

---

## Cross-cutting tracks (run alongside phases)

**Track D — Marketing site completion**
- `for-gyms.html` · `for-trainers.html` · `for-dietitians.html` — role-specific landings
- `for-members.html` — consumer landing
- `careers.html` — open roles list + role detail
- `press.html` — press kit, press releases, brand assets
- `status.html` — live status page · incidents · uptime · subscribe
- `case-studies.html` — provider success stories (3 vignettes)

→ **8 new pages**

**Track E — Notifications kit**
- Push notification templates (iOS + Android · 8 templates from `emails.html` mirrored)
- SMS templates (4 critical-path messages)
- In-app notification components (toast types, banner types, in-line nudges)
- All catalogued in a `notifications.html` reference page like `emails.html`

→ **1 reference page · 12 template specs**

**Track F — Brand & design system polish**
- Illustration guidelines (when / how to use illustration vs photo vs icon)
- Motion principles doc (when to animate, easing curves, timing rules)
- Accessibility checklist per component
- Print stylesheet for receipts / PDF plans / tax docs

→ **4 doc pages**

**Track G — Animation & micro-interactions**
- Page transitions between sibling pages
- Loading skeletons wired into every async surface
- Hover states pass for cards / buttons / list items
- Real-time updates for: payments dashboard, audit log, support tickets, gym check-ins

→ **No new pages, polish pass across ~30 existing surfaces**

---

## Summary

| Phase | Pages | Notes |
|---|---|---|
| 1 · System completeness | 9 + primitives + empty-state pass | Unblocks everything |
| 2 · Auth & lifecycle | 6 | Closes auth gaps |
| 3 · Onboarding deep-flows | 24 | Per-role |
| 4 · Marketplace & booking gaps | 7 | Consumer happy-path |
| 5 · Consumer health & activity | 9 | Logged-in member dashboards |
| 6 · Gym deep-flows | 7 | Drilldowns + tax + marketing |
| 7 · Trainer & dietitian deep-flows | 9 | Per-role completion |
| 8 · Admin moderation & deep-flows | 14 | Listing / dispute / fraud / user / analytics |
| D · Marketing site | 8 | Role landings + careers + status + press |
| E · Notifications kit | 1 + specs | Push + SMS + in-app |
| F · Brand & design system polish | 4 | Docs |
| G · Animation & polish | 0 new | Pass across existing |
| **Total** | **~98 new surfaces** | + polish/docs |

**Recommended build order:** 1 → 2 → 4 → 6/7/8 (parallel by role) → 5 → 3 → D/E/F/G (parallel).

This gets us from 72% → ~95% complete-for-launch (mobile excluded). Phase 1 alone takes us to ~78% and removes every "dead-end" feel from the current build.

Ready when you are. Say the word on which phase(s) to start and I'll begin in the next turn.
